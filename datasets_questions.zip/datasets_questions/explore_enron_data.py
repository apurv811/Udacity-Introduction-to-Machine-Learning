#!/usr/bin/python

""" 
    Starter code for exploring the Enron dataset (emails + finances);
    loads up the dataset (pickled dict of dicts).

    The dataset has the form:
    enron_data["LASTNAME FIRSTNAME MIDDLEINITIAL"] = { features_dict }

    {features_dict} is a dictionary of features associated with that person.
    You should explore features_dict as part of the mini-project,
    but here's an example to get you started:

    enron_data["SKILLING JEFFREY K"]["bonus"] = 5600000
    
"""

import pickle

enron_data = pickle.load(open("../final_project/final_project_dataset.pkl", "rb"))

print("Total people: ", len(enron_data))
print("Features Available: ", len(enron_data['SKILLING JEFFREY K']))

poi = 0
for person in enron_data:
	if(enron_data[person]['poi']==1):
		poi += 1
print("Total POIs: ", poi)

poiFile = open("../final_project/poi_names.txt")
poi2 = 0
lines = poiFile.readlines()
for line in lines:
	if line[0] == '(':
		poi2 +=1
print("Total POIs in poi_names file: ", poi2)

print("Stocks Belonging to PRENTICE JAMES: ", enron_data['PRENTICE JAMES']['total_stock_value'])

print("Emails from Wesley Colwell to poi: ", enron_data['COLWELL WESLEY']['from_this_person_to_poi'])

print("Value of Stock Options excercised by Jeffrey K Skilling: ", enron_data['SKILLING JEFFREY K']['exercised_stock_options'])

print("Money got by Lay: ", enron_data['LAY KENNETH L']['total_payments'])

print("Money got by Fastow: ", enron_data['FASTOW ANDREW S']['total_payments'])

print("Money got by Skilling: ", enron_data['SKILLING JEFFREY K']['total_payments'])

countSalary = 0
countEmail = 0
for person in enron_data:
	if enron_data[person]['salary'] != 'NaN':
		countSalary +=1;
	if enron_data[person]['email_address'] != 'NaN':
		countEmail +=1
print("Salary count: ", countSalary)
print("Email count: ", countEmail)

countNaNPayment = 0
for person in enron_data:
	if enron_data[person]['total_payments'] == 'NaN':
		countNaNPayment +=1;
print("Total NaN payments: ", countNaNPayment)
print("Percentage of total NaN payments: ", (countNaNPayment/len(enron_data))*100)

countNaNPoi = 0
for person in enron_data:
	if (enron_data[person]['poi']==1 and enron_data[person]['total_payments'] == 'NaN'):
		countNaNPoi += 1
print("Total NaN in POIs: ", countNaNPoi)